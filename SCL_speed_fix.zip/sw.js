/* SCL performance service worker.
   Keep a recent copy of the app shell for fast repeat visits and offline fallback.
   Never cache Supabase/API requests or clear unrelated origin caches. */
const SCL_CACHE = "scl-shell-v2";
const SCL_ASSET_CACHE = "scl-assets-v2";
const SHELL_URL = "./";

self.addEventListener("install", (event) => {
  // Activate promptly; do not make installation wait for the large HTML shell.
  event.waitUntil(self.skipWaiting());
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys
        .filter((key) =>
          (key.startsWith("scl-shell-") && key !== SCL_CACHE) ||
          (key.startsWith("scl-assets-") && key !== SCL_ASSET_CACHE))
        .map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

async function refreshNavigation(request, cached) {
  try {
    const response = await fetch(request, { cache: "no-cache" });
    if (response && response.ok && response.type === "basic") {
      const cache = await caches.open(SCL_CACHE);
      await cache.put(request, response.clone());
    }
    return response;
  } catch (error) {
    if (cached) return cached;
    const fallback = await caches.match(SHELL_URL);
    if (fallback) return fallback;
    throw error;
  }
}

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  // Leave Supabase, auth, API calls, and all third-party requests untouched.
  if (url.origin !== self.location.origin) return;

  if (request.mode === "navigate") {
    event.respondWith((async () => {
      const cache = await caches.open(SCL_CACHE);
      const cached = await cache.match(request) || await cache.match(SHELL_URL);
      // Show the last good page immediately on repeat visits, then refresh it.
      const update = refreshNavigation(request, cached);
      if (cached) {
        event.waitUntil(update.then(() => undefined).catch(() => undefined));
        return cached;
      }
      return update;
    })());
    return;
  }

  // Cache successful same-origin static assets; network-first on first load.
  if (["script", "style", "image", "font"].includes(request.destination)) {
    event.respondWith((async () => {
      const cache = await caches.open(SCL_ASSET_CACHE);
      const cached = await cache.match(request);
      if (cached) return cached;
      const response = await fetch(request);
      if (response && response.ok && response.type === "basic") {
        await cache.put(request, response.clone());
      }
      return response;
    })());
  }
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true })
    .then((clients) => {
      for (const client of clients) {
        if ("focus" in client) return client.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow("./");
    }));
});
